package fr.epsi.b3.recensement;

import java.util.ArrayList;

public class Departement {
private String numDepartement ;
private String population ;
private ArrayList<Ville>listeVille;
public String getNumDepartement() {
	return numDepartement;
}
public void setNumDepartement(String numDepartement) {
	this.numDepartement = numDepartement;
}
public String getPopulation() {
	return population;
}
public void setPopulation(String population) {
	this.population = population;
}
public ArrayList<Ville> getListeVille() {
	return listeVille;
}
public void setListeVille(ArrayList<Ville> listeVille) {
	this.listeVille = listeVille;
	
	
}
public Departement(String numDepartement) {
	super();
	this.numDepartement = numDepartement;
	this.listeVille = new ArrayList<Ville>();
}


public void ajoutVille(Ville v)
{
	this.listeVille.add(v);
}
}
