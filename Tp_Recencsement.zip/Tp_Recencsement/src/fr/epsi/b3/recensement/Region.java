package fr.epsi.b3.recensement;

import java.util.ArrayList;

public class Region {

	
	private String codeRegion ;
	private String nomRegion;
	private String populationRegion;
	private ArrayList<Ville>listeVille;

	public String getCodeRegion() {
		return codeRegion;
	}
	public void setCodeRegion(String codeRegion) {
		this.codeRegion = codeRegion;
	}
	public String getNomRegion() {
		return nomRegion;
	}
	public void setNomRegion(String nomRegion) {
		this.nomRegion = nomRegion;
	}
	public String getPopulationRegion() {
		return populationRegion;
	}
	public void setPopulationRegion(String populationRegion) {
		this.populationRegion = populationRegion;
	}
	
	public ArrayList<Ville> getListeVille() {
		return listeVille;
	}
	
	public void setListeVille(ArrayList<Ville> listeVille) {
		this.listeVille = listeVille;
		
		
	}
	public Region(String codeRegion, String nomRegion) {
		super();
		this.codeRegion = codeRegion;
		this.nomRegion = nomRegion;
		this.listeVille = new ArrayList<Ville>();
	
	}
	
	public void ajoutVille(Ville v)
	{
		this.listeVille.add(v);
	}
	
}
