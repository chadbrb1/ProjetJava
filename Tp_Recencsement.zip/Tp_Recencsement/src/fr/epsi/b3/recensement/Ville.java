package fr.epsi.b3.recensement;

public class Ville implements Comparable<Ville>{
private String nomVille ;
private String populationVille;
private String departement;
private String Region;
public String getRegion() {
	return Region;
}
public void setRegion(String region) {
	Region = region;
}
public String getDepartement() {
	return departement;
}
public void setDepartement(String departement) {
	this.departement = departement;
}
public String getNomVille() {
	return nomVille;
}
public void setNomVille(String nomVille) {
	this.nomVille = nomVille;
}
public String getPopulationVille() {
	return populationVille;
}
public void setPopulationVille(String populationVille) {
	this.populationVille = populationVille;
}
public Ville(String nomVille, String populationVille, String departement, String region) {
	super();
	this.nomVille = nomVille;
	this.populationVille = populationVille;
	this.departement = departement;
	Region = region;
}

@Override
public int compareTo(Ville v) {
 //trions les employés selon leur age dans l'ordre croiddant
 //retroune un entier négative, zéro ou positive si l'age 
 //de cet employé est moins que, égale à ou supérieur à l'objet comparé avec
       return (Integer.parseInt(v.getPopulationVille()) - Integer.parseInt(this.getPopulationVille()));
}

}
