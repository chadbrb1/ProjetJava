package fr.epsi.b3.ihm;
import fr.epsi.b3.recensement.*;

import java.awt.BorderLayout;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.DefaultListModel;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JList;

public class Accueil extends JFrame implements ActionListener, ItemListener{

	private JPanel contentPane;
	private JButton buttonQuitter;
	private JLabel lblNewLabel;
	private JButton btnCartes_1_2;


	/**
	 * Create the frame.
	 */
	public Accueil() {
		
		setAlwaysOnTop(true);
		setTitle("Tp Recencement");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,50, 776, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		buttonQuitter = new JButton("Quitter");
		buttonQuitter.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		buttonQuitter.setBackground(Color.WHITE);
		buttonQuitter.setForeground(Color.BLACK);
		buttonQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonQuitter)
				{
					System.exit(0);
					
				}
			}
		});

		buttonQuitter.setBounds(591, 338, 155, 44);
		contentPane.add(buttonQuitter);
		
		lblNewLabel = new JLabel("Recencement");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(17, 6, 717, 53);
		contentPane.add(lblNewLabel);
		
		
		ArrayList<Region>region = Application.returnListRegionTriee();
		ArrayList<Departement>departement = Application.returnListDepartementTrie();
		
		ArrayList<String> region10Plus = new ArrayList<String>();
		ArrayList<String> departement10Plus = new ArrayList<String>();
		
		for(int i = 0 ; i < region.size(); i ++)
		{
			region10Plus.add(region.get(i).getNomRegion());
		}
		for(int i = 0; i < departement.size(); i++)
		{
			departement10Plus.add(departement.get(i).getNumDepartement());
			
		}
		
		
		
		JButton btnCartes_1 = new JButton("Départements");
		btnCartes_1.setForeground(Color.BLACK);
		btnCartes_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1.setBackground(Color.WHITE);
		btnCartes_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
			
				PopDepartement frame = new PopDepartement();
				frame.setVisible(true);
				Accueil.this.dispose();
					
				
			}
		});
		btnCartes_1.setBounds(424, 338, 155, 44);
		contentPane.add(btnCartes_1);
		
		JButton btnCartes_1_1 = new JButton("Régions");
		btnCartes_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PopRegion frame = new PopRegion();
				frame.setVisible(true);
				Accueil.this.dispose();
			}
		});
		btnCartes_1_1.setForeground(Color.BLACK);
		btnCartes_1_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1_1.setBackground(Color.WHITE);
		btnCartes_1_1.setBounds(196, 338, 155, 44);
		contentPane.add(btnCartes_1_1);
		
		btnCartes_1_2 = new JButton("Population");
		btnCartes_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Population frame = new Population();
				frame.setVisible(true);
				Accueil.this.dispose();
			}
		});
		btnCartes_1_2.setForeground(Color.BLACK);
		btnCartes_1_2.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1_2.setBackground(Color.WHITE);
		btnCartes_1_2.setBounds(29, 338, 155, 44);
		contentPane.add(btnCartes_1_2);
		
		
		DefaultListModel<String> model = new DefaultListModel<>();
		JList<String> list = new JList<>( model );
		
		DefaultListModel<String> model2 = new DefaultListModel<>();
		JList<String> list2 = new JList<>( model2 );
		
		JList<String> listRegion = new JList<>( model );
		for ( int i = 0; i < region.size(); i++ ){
			  model.addElement( region.get(i).getNomRegion() );
			}
		listRegion.setBounds(29, 99, 334, 234);
		contentPane.add(listRegion);
		
		JList listDepartement = new JList<>( model2 );
		for ( int i = 0; i < departement.size(); i++ ){
			  model2.addElement( departement.get(i).getNumDepartement() );
			}
		listDepartement.setBounds(405, 99, 341, 234);
		contentPane.add(listDepartement);
		
		JLabel lblRegionPLus = new JLabel("10 Régions les plus peuplées");
		lblRegionPLus.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegionPLus.setForeground(Color.BLACK);
		lblRegionPLus.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblRegionPLus.setBackground(Color.WHITE);
		lblRegionPLus.setBounds(53, 49, 260, 53);
		contentPane.add(lblRegionPLus);
		
		JLabel lblDpartementsLes = new JLabel("10 Départements les plus peuplées");
		lblDpartementsLes.setHorizontalAlignment(SwingConstants.CENTER);
		lblDpartementsLes.setForeground(Color.BLACK);
		lblDpartementsLes.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblDpartementsLes.setBackground(Color.WHITE);
		lblDpartementsLes.setBounds(447, 49, 260, 53);
		contentPane.add(lblDpartementsLes);

	}


	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
