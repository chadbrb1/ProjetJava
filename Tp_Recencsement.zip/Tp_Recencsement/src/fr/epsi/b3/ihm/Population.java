package fr.epsi.b3.ihm;
import fr.epsi.b3.recensement.*;
import java.awt.BorderLayout;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.DefaultListModel;
import javax.swing.DropMode;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JList;
import javax.swing.JTextPane;
import javax.swing.JComboBox;

public class Population extends JFrame implements ActionListener, ItemListener{

	private JPanel contentPane;
	private JButton buttonQuitter;
	private JLabel lblNewLabel;
	private JButton btnAccueil;


	/**
	 * Create the frame.
	 */
	public Population() {
		
		setAlwaysOnTop(true);
		setTitle("Tp Recensement");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0,50, 776, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		buttonQuitter = new JButton("Quitter");
		buttonQuitter.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		buttonQuitter.setBackground(Color.WHITE);
		buttonQuitter.setForeground(Color.BLACK);
		buttonQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonQuitter)
				{
					System.exit(0);
					
				}
			}
		});

		buttonQuitter.setBounds(591, 338, 155, 44);
		contentPane.add(buttonQuitter);
		
		lblNewLabel = new JLabel("Recencement");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(17, 6, 717, 53);
		contentPane.add(lblNewLabel);
		
		
		ArrayList<Ville>ville = Application.triVille();
		
		
		
		
		
		
		JButton btnCartes_1 = new JButton("Départements");
		btnCartes_1.setForeground(Color.BLACK);
		btnCartes_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1.setBackground(Color.WHITE);
		btnCartes_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				PopDepartement frame = new PopDepartement();
				frame.setVisible(true);
				Population.this.dispose();
			}
		});
		btnCartes_1.setBounds(424, 338, 155, 44);
		contentPane.add(btnCartes_1);
		
		JButton btnCartes_1_1 = new JButton("Régions");
		btnCartes_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PopRegion frame = new PopRegion();
				frame.setVisible(true);
				Population.this.dispose();
			}
		});
		btnCartes_1_1.setForeground(Color.BLACK);
		btnCartes_1_1.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnCartes_1_1.setBackground(Color.WHITE);
		btnCartes_1_1.setBounds(196, 338, 155, 44);
		contentPane.add(btnCartes_1_1);
		
		btnAccueil = new JButton("Accueil");
		btnAccueil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Accueil frame = new Accueil();
				frame.setVisible(true);
				Population.this.dispose();
			}
		});
		btnAccueil.setForeground(Color.BLACK);
		btnAccueil.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 19));
		btnAccueil.setBackground(Color.WHITE);
		btnAccueil.setBounds(29, 338, 155, 44);
		contentPane.add(btnAccueil);
		
		
		DefaultListModel<String> model = new DefaultListModel<>();
		
		
		JList<String> listRegion = new JList<>( model );
		for ( int i = 0; i < ville.size(); i++ ){
			  model.addElement( ville.get(i).getNomVille() );
			}
		listRegion.setBounds(424, 92, 322, 209);
		contentPane.add(listRegion);
		
		
		JLabel lblDpartementsLes = new JLabel("Population d'une ville donnée");
		lblDpartementsLes.setHorizontalAlignment(SwingConstants.CENTER);
		lblDpartementsLes.setForeground(Color.BLACK);
		lblDpartementsLes.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblDpartementsLes.setBackground(Color.WHITE);
		lblDpartementsLes.setBounds(79, 49, 260, 38);
		contentPane.add(lblDpartementsLes);
		
		JTextPane txtVille = new JTextPane();
		txtVille.setBounds(242, 92, 148, 29);
		contentPane.add(txtVille);
		
		JComboBox comboBoxVille = new JComboBox(vectorVille());
		comboBoxVille.setBounds(6, 94, 194, 27);
		contentPane.add(comboBoxVille);
		
		JLabel lblPopulationDuneRgion = new JLabel("Population d'une région donnée");
		lblPopulationDuneRgion.setHorizontalAlignment(SwingConstants.CENTER);
		lblPopulationDuneRgion.setForeground(Color.BLACK);
		lblPopulationDuneRgion.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblPopulationDuneRgion.setBackground(Color.WHITE);
		lblPopulationDuneRgion.setBounds(79, 134, 260, 44);
		contentPane.add(lblPopulationDuneRgion);
		
		JComboBox comboBoxRegion = new JComboBox(vectorRegion());
		comboBoxRegion.setBounds(6, 179, 194, 27);
		contentPane.add(comboBoxRegion);
		
		JTextPane txtRegion = new JTextPane();
		txtRegion.setBounds(242, 179, 148, 29);
		contentPane.add(txtRegion);
		
		JButton btnRegion = new JButton("OK");
		btnRegion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource()==btnRegion)
				{
					txtRegion.setText(Application.rechPopRegion(comboBoxRegion.getSelectedItem().toString()));
				}
			}
		});
		btnRegion.setForeground(Color.BLACK);
		btnRegion.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 12));
		btnRegion.setBackground(Color.WHITE);
		btnRegion.setBounds(196, 179, 44, 27);
		contentPane.add(btnRegion);
		
		
		
		JButton btnVille = new JButton("OK");
		btnVille.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource()==btnVille)
				{
					txtVille.setText(Application.rechPopVille(comboBoxVille.getSelectedItem().toString()));
				}
				
			}
		});
		btnVille.setForeground(Color.BLACK);
		btnVille.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 12));
		btnVille.setBackground(Color.WHITE);
		btnVille.setBounds(196, 94, 44, 27);
		contentPane.add(btnVille);
		
		JLabel lblPopulationDunDpartement = new JLabel("Population d'un département donné");
		lblPopulationDunDpartement.setHorizontalAlignment(SwingConstants.CENTER);
		lblPopulationDunDpartement.setForeground(Color.BLACK);
		lblPopulationDunDpartement.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblPopulationDunDpartement.setBackground(Color.WHITE);
		lblPopulationDunDpartement.setBounds(89, 229, 260, 44);
		contentPane.add(lblPopulationDunDpartement);
		
		JComboBox comboBoxDepartement = new JComboBox(vectorDepartement());
		comboBoxDepartement.setBounds(6, 274, 194, 27);
		contentPane.add(comboBoxDepartement);
		JTextPane txtDep = new JTextPane();
		txtDep.setBounds(242, 272, 148, 29);
		contentPane.add(txtDep);
		JButton btnDep = new JButton("OK");
		btnDep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (e.getSource()==btnDep)
				{
					txtDep.setText(Application.rechPopDepartement(comboBoxDepartement.getSelectedItem().toString()));
				}
			}
		});
		btnDep.setForeground(Color.BLACK);
		btnDep.setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 12));
		btnDep.setBackground(Color.WHITE);
		btnDep.setBounds(196, 274, 44, 27);
		contentPane.add(btnDep);
		
		
		
		JLabel lblVillesLes = new JLabel("10 villes les plus peuplées de France");
		lblVillesLes.setHorizontalAlignment(SwingConstants.CENTER);
		lblVillesLes.setForeground(Color.BLACK);
		lblVillesLes.setFont(new Font("Arial Unicode MS", Font.ITALIC, 14));
		lblVillesLes.setBackground(Color.WHITE);
		lblVillesLes.setBounds(447, 49, 260, 38);
		contentPane.add(lblVillesLes);

	}


	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public static Vector<String> vectorVille()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Ville> vi = Application.returnListVille();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNomVille());
		}
		
		return v;
	}
	
	public static Vector<String> vectorRegion()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Region> vi = Application.returnListRegion();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNomRegion());
		}
		
		return v;
	}
	
	public static Vector<String> vectorDepartement()
	{
		Vector<String> v = new Vector<String>();
		ArrayList<Departement> vi = Application.returnListDepartement();
		for (int i = 0 ; i < vi.size(); i++)
		{
			v.add(vi.get(i).getNumDepartement());
		}
		
		return v;
	}
}
